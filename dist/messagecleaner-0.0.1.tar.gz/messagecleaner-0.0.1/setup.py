from setuptools import setup

setup(
    name='messagecleaner',
    version='0.0.1',
    author='LafA',
    description='Чистит сообщение от мусора.',
#    packages=['messagecleaner'],
    install_requires=[
        'rasa',
    ]
)
